package view;

import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import model.Usuario;
import util.SessaoUsuario;



public class FrmPrincipal extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmPrincipal.class.getName());

   
    public FrmPrincipal() {
        initComponents();
          setLocationRelativeTo(null);

    setExtendedState(
            javax.swing.JFrame.MAXIMIZED_BOTH
    );

    carregarUsuario();
    aplicarPermissoes();
    
    }
    
    
    private void carregarUsuario(){
        
        Usuario usuario = 
                SessaoUsuario.getUsuarioLogado();
        
        if (usuario != null) {

        lblUsuario.setText(
                "Usuário: "
                + usuario.getNome()
        );

        lblNivel.setText(
                "Nível: "
                + usuario.getNivel()
        );

    } else {

        lblUsuario.setText(
                "Usuário: não identificado"
        );

        lblNivel.setText(
                "Nível: não identificado"
        );
    }

    }
private void aplicarPermissoes() {

    if (SessaoUsuario.isMaster()) {

        mnuUsuarios.setEnabled(true);

        mnuContasPagar.setEnabled(true);

    } else {

        mnuUsuarios.setEnabled(false);

        mnuContasPagar.setEnabled(false);
    }
}
   
   private void abrirTela(
        JInternalFrame tela
) {

    for (
            JInternalFrame frame :
            desktopPrincipal.getAllFrames()
    ) {

        if (
                frame.getClass()
                .equals(
                        tela.getClass()
                )
        ) {

            try {

                frame.setSelected(true);

                if (frame.isIcon()) {

                    frame.setIcon(false);
                }

            } catch (Exception erro) {

                JOptionPane.showMessageDialog(
                        this,
                        "Não foi possível selecionar a tela."
                );
            }

            frame.toFront();

            return;
        }
    }

    desktopPrincipal.add(tela);

    tela.setVisible(true);

    centralizarInternalFrame(tela);
}
  private void centralizarInternalFrame(
        JInternalFrame tela
) {

    int x =
            (
                desktopPrincipal.getWidth()
                - tela.getWidth()
            ) / 2;

    int y =
            (
                desktopPrincipal.getHeight()
                - tela.getHeight()
            ) / 2;

    if (x < 0) {

        x = 0;
    }

    if (y < 0) {

        y = 0;
    }

    tela.setLocation(x, y);
}
  
  
  
  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenuBar3 = new javax.swing.JMenuBar();
        jMenu6 = new javax.swing.JMenu();
        jMenu7 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();
        lblUsuario = new javax.swing.JLabel();
        lblNivel = new javax.swing.JLabel();
        desktopPrincipal = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        mnuLogout = new javax.swing.JMenuItem();
        mnuSair = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        mnuClientes = new javax.swing.JMenuItem();
        mnuFornecedores = new javax.swing.JMenuItem();
        mnuProdutos = new javax.swing.JMenuItem();
        mnuUsuarios = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        mnuCompras = new javax.swing.JMenuItem();
        mnuVendas = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        mnuContasPagar = new javax.swing.JMenuItem();
        mnuContasReceber = new javax.swing.JMenuItem();
        jMenu9 = new javax.swing.JMenu();
        mnuSobre = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        jMenuItem2.setText("jMenuItem2");

        jMenu4.setText("File");
        jMenuBar2.add(jMenu4);

        jMenu5.setText("Edit");
        jMenuBar2.add(jMenu5);

        jMenu6.setText("File");
        jMenuBar3.add(jMenu6);

        jMenu7.setText("Edit");
        jMenuBar3.add(jMenu7);

        jMenuItem3.setText("jMenuItem3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblUsuario.setText("Usuario:");

        lblNivel.setText("Nivel:");

        javax.swing.GroupLayout desktopPrincipalLayout = new javax.swing.GroupLayout(desktopPrincipal);
        desktopPrincipal.setLayout(desktopPrincipalLayout);
        desktopPrincipalLayout.setHorizontalGroup(
            desktopPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        desktopPrincipalLayout.setVerticalGroup(
            desktopPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 345, Short.MAX_VALUE)
        );

        jMenu1.setText("Sistema");

        mnuLogout.setText("Logout");
        mnuLogout.addActionListener(this::mnuLogoutActionPerformed);
        jMenu1.add(mnuLogout);

        mnuSair.setText("Sair");
        mnuSair.addActionListener(this::mnuSairActionPerformed);
        jMenu1.add(mnuSair);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Cadastros");

        mnuClientes.setText("Clientes");
        mnuClientes.addActionListener(this::mnuClientesActionPerformed);
        jMenu2.add(mnuClientes);

        mnuFornecedores.setText("Fornecedores");
        mnuFornecedores.addActionListener(this::mnuFornecedoresActionPerformed);
        jMenu2.add(mnuFornecedores);

        mnuProdutos.setText("Produtos");
        mnuProdutos.addActionListener(this::mnuProdutosActionPerformed);
        jMenu2.add(mnuProdutos);

        mnuUsuarios.setText("Usuarios");
        mnuUsuarios.addActionListener(this::mnuUsuariosActionPerformed);
        jMenu2.add(mnuUsuarios);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Movimentos");

        mnuCompras.setText("Compras");
        mnuCompras.addActionListener(this::mnuComprasActionPerformed);
        jMenu3.add(mnuCompras);

        mnuVendas.setText("Vendas");
        mnuVendas.addActionListener(this::mnuVendasActionPerformed);
        jMenu3.add(mnuVendas);

        jMenuBar1.add(jMenu3);

        jMenu8.setText("Financeiro");

        mnuContasPagar.setText("Contas a Pagar");
        mnuContasPagar.addActionListener(this::mnuContasPagarActionPerformed);
        jMenu8.add(mnuContasPagar);

        mnuContasReceber.setText("Contas a Receber");
        mnuContasReceber.addActionListener(this::mnuContasReceberActionPerformed);
        jMenu8.add(mnuContasReceber);

        jMenuBar1.add(jMenu8);

        jMenu9.setText("Ajuda");

        mnuSobre.setText("Sobre");
        mnuSobre.addActionListener(this::mnuSobreActionPerformed);
        jMenu9.add(mnuSobre);

        jMenuBar1.add(jMenu9);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktopPrincipal)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(lblUsuario)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 334, Short.MAX_VALUE)
                .addComponent(lblNivel)
                .addGap(24, 24, 24))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(desktopPrincipal)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNivel)
                    .addComponent(lblUsuario))
                .addGap(27, 27, 27))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnuClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuClientesActionPerformed
       abrirTela(
            new FrmClientes()
    );

    }//GEN-LAST:event_mnuClientesActionPerformed

    private void mnuProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuProdutosActionPerformed
  abrirTela(
            new FrmProduto()
    );        
    }//GEN-LAST:event_mnuProdutosActionPerformed

    private void mnuComprasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuComprasActionPerformed
  
    }//GEN-LAST:event_mnuComprasActionPerformed

    private void mnuContasReceberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuContasReceberActionPerformed
     
    }//GEN-LAST:event_mnuContasReceberActionPerformed

    private void mnuFornecedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuFornecedoresActionPerformed
      abrirTela(
            new FrmFornecedor()
    );
    }//GEN-LAST:event_mnuFornecedoresActionPerformed

    private void mnuUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuUsuariosActionPerformed
          if (!SessaoUsuario.isMaster()) {

        JOptionPane.showMessageDialog(
                this,
                "Acesso permitido somente para usuário MASTER."
        );

        return;
    }

    
    }//GEN-LAST:event_mnuUsuariosActionPerformed

    private void mnuVendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuVendasActionPerformed
     
    }//GEN-LAST:event_mnuVendasActionPerformed

    private void mnuContasPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuContasPagarActionPerformed
       if (!SessaoUsuario.isMaster()) {

        JOptionPane.showMessageDialog(
                this,
                "Acesso permitido somente para usuário MASTER."
        );

        return;
    }

   
    }//GEN-LAST:event_mnuContasPagarActionPerformed

    private void mnuLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuLogoutActionPerformed
    int resposta =
            JOptionPane.showConfirmDialog(
                    this,
                    "Deseja encerrar a sessão atual?",
                    "Logout",
                    JOptionPane.YES_NO_OPTION
            );

    if (
            resposta
            == JOptionPane.YES_OPTION
    ) {

        SessaoUsuario.encerrar();

        FrmLogin login =
                new FrmLogin();

        login.setVisible(true);

        dispose();
    }
    }//GEN-LAST:event_mnuLogoutActionPerformed

    private void mnuSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuSairActionPerformed
       int resposta =
            JOptionPane.showConfirmDialog(
                    this,
                    "Deseja realmente encerrar o FerragemGK?",
                    "Sair",
                    JOptionPane.YES_NO_OPTION
            );

    if (
            resposta
            == JOptionPane.YES_OPTION
    ) {

        System.exit(0);
    }
    }//GEN-LAST:event_mnuSairActionPerformed

    private void mnuSobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuSobreActionPerformed
      JOptionPane.showMessageDialog(
            this,
            "FerragemGK\n"
            + "Sistema desenvolvido em Java Swing\n"
            + "Banco de dados PostgreSQL"
    );
    }//GEN-LAST:event_mnuSobreActionPerformed

    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(() -> new FrmPrincipal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane desktopPrincipal;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenu jMenu9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuBar jMenuBar3;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JLabel lblNivel;
    private javax.swing.JLabel lblUsuario;
    private javax.swing.JMenuItem mnuClientes;
    private javax.swing.JMenuItem mnuCompras;
    private javax.swing.JMenuItem mnuContasPagar;
    private javax.swing.JMenuItem mnuContasReceber;
    private javax.swing.JMenuItem mnuFornecedores;
    private javax.swing.JMenuItem mnuLogout;
    private javax.swing.JMenuItem mnuProdutos;
    private javax.swing.JMenuItem mnuSair;
    private javax.swing.JMenuItem mnuSobre;
    private javax.swing.JMenuItem mnuUsuarios;
    private javax.swing.JMenuItem mnuVendas;
    // End of variables declaration//GEN-END:variables
}
