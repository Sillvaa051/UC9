
package view;

import dao.ClienteDao;

import java.util.List;

import javax.swing.JOptionPane;

import javax.swing.table.DefaultTableModel;

import model.Cliente;

import util.SessaoUsuario;


public class FrmClientes extends javax.swing.JInternalFrame {

    private final ClienteDao clienteDAO =
        new ClienteDao();
    
    private long idClienteSelecionado = 0;
    
    
    public FrmClientes() {
        initComponents();
         configurarTela();
         listarClientes();
         limparCampos();
         
           
    }
    private void configurarTela() {

    txtCodigo.setEditable(false);

    btnExcluir.setEnabled(
            SessaoUsuario.isMaster()
    );

    tblClientes.setSelectionMode(
            javax.swing.ListSelectionModel
                    .SINGLE_SELECTION
    );

    tblClientes.setAutoCreateRowSorter(
            true
    );

    tblClientes.setModel(
            criarModeloTabela()
    );
}

private DefaultTableModel criarModeloTabela() {

    return new DefaultTableModel(
            new Object[]{
                "Código",
                "Nome",
                "CPF",
                "Telefone",
                "Email",
                "Cidade",
                "UF",
                "Ativo"
            },
            0
    ) {

        @Override
        public boolean isCellEditable(
                int row,
                int column
        ) {

            return false;
        }
    };
}

private void preencherTabela(
        List<Cliente> clientes
) {

    DefaultTableModel modelo =
            (DefaultTableModel)
            tblClientes.getModel();

    modelo.setRowCount(0);

    for (
            Cliente cliente :
            clientes
    ) {

        modelo.addRow(
                new Object[]{
                    cliente.getIdCliente(),
                    cliente.getNome(),
                    cliente.getCpf(),
                    cliente.getTelefone(),
                    cliente.getEmail(),
                    cliente.getCidade(),
                    cliente.getUf(),
                    cliente.isAtivo()
                            ? "Sim"
                            : "Não"
                }
        );
    }
}
    
    
    private void listarClientes() {

    try {

        preencherTabela(
                clienteDAO.listarTodos()
        );

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Erro ao carregar clientes.\n"
                + erro.getMessage()
        );
    }
}
    private void limparCampos() {

    idClienteSelecionado = 0;

    txtCodigo.setText("");
    txtNome.setText("");
    txtCpf.setText("");
    txtTelefone.setText("");
    txtEmail.setText("");
    txtEndereco.setText("");
    txtNumero.setText("");
    txtComplemento.setText("");
    txtBairro.setText("");
    txtCidade.setText("");
    txtCep.setText("");

    cmbUf.setSelectedIndex(0);

    chkAtivo.setSelected(true);

    txtNome.requestFocus();
}
    
    private boolean validarCampos() {

    if (
            txtNome
            .getText()
            .trim()
            .isEmpty()
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Informe o nome do cliente."
        );

        txtNome.requestFocus();

        return false;
    }

    if (
            cmbUf.getSelectedIndex() == 0
            && !txtCidade
                    .getText()
                    .trim()
                    .isEmpty()
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Selecione a UF."
        );

        cmbUf.requestFocus();

        return false;
    }

    return true;
}  
    
    private Cliente criarClienteComCampos() {

    Cliente cliente =
            new Cliente();

    cliente.setIdCliente(
            idClienteSelecionado
    );

    cliente.setNome(
            txtNome
            .getText()
            .trim()
    );

    cliente.setCpf(
            txtCpf
            .getText()
            .trim()
    );

    cliente.setTelefone(
            txtTelefone
            .getText()
            .trim()
    );

    cliente.setEmail(
            txtEmail
            .getText()
            .trim()
    );

    cliente.setEndereco(
            txtEndereco
            .getText()
            .trim()
    );

    cliente.setNumero(
            txtNumero
            .getText()
            .trim()
    );

    cliente.setComplemento(
            txtComplemento
            .getText()
            .trim()
    );

    cliente.setBairro(
            txtBairro
            .getText()
            .trim()
    );

    cliente.setCidade(
            txtCidade
            .getText()
            .trim()
    );

    if (
            cmbUf.getSelectedIndex() > 0
    ) {

        cliente.setUf(
                cmbUf
                .getSelectedItem()
                .toString()
        );

    } else {

        cliente.setUf("");
    }

    cliente.setCep(
            txtCep
            .getText()
            .trim()
    );

    cliente.setAtivo(
            chkAtivo.isSelected()
    );

    return cliente;
}
    private void carregarClienteSelecionado() {

    int linha =
            tblClientes.getSelectedRow();

    if (linha == -1) {

        JOptionPane.showMessageDialog(
                this,
                "Selecione um cliente na tabela."
        );

        return;
    }

    int linhaModelo =
            tblClientes.convertRowIndexToModel(
                    linha
            );

    long idCliente =
            Long.parseLong(
                    tblClientes
                    .getModel()
                    .getValueAt(
                            linhaModelo,
                            0
                    )
                    .toString()
            );

    try {

        Cliente cliente =
                clienteDAO.buscarPorId(
                        idCliente
                );

        if (cliente == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cliente não encontrado."
            );

            return;
        }

        preencherCampos(
                cliente
        );

        tabCliente.setSelectedIndex(
                0
        );

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Erro ao carregar cliente.\n"
                + erro.getMessage()
        );
    }
}
    private void preencherCampos(
        Cliente cliente
) {

    idClienteSelecionado =
            cliente.getIdCliente();

    txtCodigo.setText(
            String.valueOf(
                    cliente.getIdCliente()
            )
    );

    txtNome.setText(
            valorTexto(
                    cliente.getNome()
            )
    );

    txtCpf.setText(
            valorTexto(
                    cliente.getCpf()
            )
    );

    txtTelefone.setText(
            valorTexto(
                    cliente.getTelefone()
            )
    );

    txtEmail.setText(
            valorTexto(
                    cliente.getEmail()
            )
    );

    txtEndereco.setText(
            valorTexto(
                    cliente.getEndereco()
            )
    );

    txtNumero.setText(
            valorTexto(
                    cliente.getNumero()
            )
    );

    txtComplemento.setText(
            valorTexto(
                    cliente.getComplemento()
            )
    );

    txtBairro.setText(
            valorTexto(
                    cliente.getBairro()
            )
    );

    txtCidade.setText(
            valorTexto(
                    cliente.getCidade()
            )
    );

    txtCep.setText(
            valorTexto(
                    cliente.getCep()
            )
    );

    if (
            cliente.getUf() != null
            && !cliente
                    .getUf()
                    .isBlank()
    ) {

        cmbUf.setSelectedItem(
                cliente.getUf()
        );

    } else {

        cmbUf.setSelectedIndex(0);
    }

    chkAtivo.setSelected(
            cliente.isAtivo()
    );
}
   
    
    private String valorTexto(
        String valor
) {

    if (valor == null) {

        return "";
    }

    return valor;
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tabCliente = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        txtCodigo = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtCpf = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtEndereco = new javax.swing.JTextField();
        txtNumero = new javax.swing.JTextField();
        txtComplemento = new javax.swing.JTextField();
        txtBairro = new javax.swing.JTextField();
        txtCidade = new javax.swing.JTextField();
        txtCep = new javax.swing.JTextField();
        cmbUf = new javax.swing.JComboBox<>();
        btnNovo = new javax.swing.JButton();
        btnSalvar = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        chkAtivo = new javax.swing.JCheckBox();
        jPanel1 = new javax.swing.JPanel();
        cbmFiltro = new javax.swing.JComboBox<>();
        txtPesquisa = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        btnLocalizar = new javax.swing.JButton();
        btnCarregar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();

        txtCodigo.setBorder(javax.swing.BorderFactory.createTitledBorder(null));

        txtNome.setBorder(javax.swing.BorderFactory.createTitledBorder(null));

        txtCpf.setBorder(javax.swing.BorderFactory.createTitledBorder(null));

        txtTelefone.setBorder(javax.swing.BorderFactory.createTitledBorder(null));
        txtTelefone.addActionListener(this::txtTelefoneActionPerformed);

        txtEmail.setBorder(javax.swing.BorderFactory.createTitledBorder(null));

        txtEndereco.setBorder(javax.swing.BorderFactory.createTitledBorder(null));
        txtEndereco.addActionListener(this::txtEnderecoActionPerformed);

        txtNumero.setBorder(javax.swing.BorderFactory.createTitledBorder(null));

        txtComplemento.setBorder(javax.swing.BorderFactory.createTitledBorder(null));

        txtBairro.setToolTipText("");
        txtBairro.setBorder(javax.swing.BorderFactory.createTitledBorder(null));

        txtCidade.setBorder(javax.swing.BorderFactory.createTitledBorder(null));
        txtCidade.addActionListener(this::txtCidadeActionPerformed);

        txtCep.setBorder(javax.swing.BorderFactory.createTitledBorder(null));

        cmbUf.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " AC", " AL", " AM ", " BA", " CE", " DF", " ES", " GO", " MA", " MT", " MS", " MG", " PA", " PB", " PR", " PE", " PI", " RJ", " RN", " RS", " RO", " RR", " SC", " SP", " SE", " TO", " " }));
        cmbUf.setToolTipText("");
        cmbUf.setBorder(javax.swing.BorderFactory.createTitledBorder(null));
        cmbUf.addActionListener(this::cmbUfActionPerformed);

        btnNovo.setBackground(new java.awt.Color(0, 204, 255));
        btnNovo.setText("Novo");
        btnNovo.addActionListener(this::btnNovoActionPerformed);

        btnSalvar.setBackground(new java.awt.Color(102, 255, 51));
        btnSalvar.setText("✔️Salvar");
        btnSalvar.addActionListener(this::btnSalvarActionPerformed);

        btnAlterar.setBackground(new java.awt.Color(255, 204, 51));
        btnAlterar.setText("🖋️Alterar");
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);

        btnExcluir.setBackground(new java.awt.Color(255, 0, 0));
        btnExcluir.setText("❌Excluir");
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);

        btnCancelar.setText("🔄️Cancelar");
        btnCancelar.addActionListener(this::btnCancelarActionPerformed);

        chkAtivo.setText("Ativo");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(50, 50, 50))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtNome)
                        .addContainerGap())
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cmbUf, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 378, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(txtComplemento, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                                .addComponent(txtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(20, 20, 20))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(btnNovo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSalvar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAlterar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnExcluir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCancelar)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtCep, javax.swing.GroupLayout.PREFERRED_SIZE, 353, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(chkAtivo)
                        .addGap(62, 62, 62))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCpf, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtNumero, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 34, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtComplemento, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtBairro, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtCidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(cmbUf, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txtCep, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnExcluir)
                            .addComponent(btnAlterar)
                            .addComponent(btnSalvar)
                            .addComponent(btnNovo)
                            .addComponent(btnCancelar)))
                    .addComponent(chkAtivo))
                .addGap(42, 42, 42))
        );

        tabCliente.addTab("Cadastro", jPanel2);

        cbmFiltro.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "NOME", "ID", "CPF", "EMAIL", " " }));
        cbmFiltro.setToolTipText("");
        cbmFiltro.addActionListener(this::cbmFiltroActionPerformed);

        txtPesquisa.setBorder(javax.swing.BorderFactory.createTitledBorder(null));
        txtPesquisa.addActionListener(this::txtPesquisaActionPerformed);

        jButton1.setBackground(new java.awt.Color(51, 153, 255));
        jButton1.setText("📝Listar Todos");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        btnLocalizar.setBackground(new java.awt.Color(102, 255, 102));
        btnLocalizar.setText("🔎Localizar");
        btnLocalizar.addActionListener(this::btnLocalizarActionPerformed);

        btnCarregar.setBackground(new java.awt.Color(255, 153, 0));
        btnCarregar.setText("🔄️Carregar");
        btnCarregar.addActionListener(this::btnCarregarActionPerformed);

        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Código", "Nome", "CPF", "Telefone", "Email", "Cidade", "UF", "Ativo"
            }
        ));
        tblClientes.addContainerListener(new java.awt.event.ContainerAdapter() {
            public void componentAdded(java.awt.event.ContainerEvent evt) {
                tblClientesComponentAdded(evt);
            }
        });
        tblClientes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblClientesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblClientes);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 606, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(txtPesquisa, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(105, 105, 105)
                        .addComponent(cbmFiltro, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(btnLocalizar)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(91, 91, 91)
                .addComponent(btnCarregar)
                .addGap(57, 57, 57))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtPesquisa)
                    .addComponent(cbmFiltro))
                .addGap(52, 52, 52)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLocalizar)
                    .addComponent(jButton1)
                    .addComponent(btnCarregar))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        tabCliente.addTab("Consulta", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabCliente)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(tabCliente)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbUfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbUfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbUfActionPerformed

    private void txtCidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCidadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCidadeActionPerformed

    private void txtTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefoneActionPerformed

    private void cbmFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbmFiltroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbmFiltroActionPerformed

    private void txtPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesquisaActionPerformed

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
            String pesquisa =
            txtPesquisa
            .getText()
            .trim();

    String filtro =
            cbmFiltro
            .getSelectedItem()
            .toString();

    if (pesquisa.isEmpty()) {

        listarClientes();

        return;
    }

    if (filtro.equals("ID")) {

        try {

            Long.parseLong(
                    pesquisa
            );

        } catch (
                NumberFormatException erro
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Para pesquisar por ID informe apenas números."
            );

            txtPesquisa.requestFocus();

            return;
        }
    }

    try {

        List<Cliente> clientes =
                clienteDAO.pesquisar(
                        filtro,
                        pesquisa
                );

        preencherTabela(
                clientes
        );

        if (clientes.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Nenhum cliente encontrado."
            );
        }

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Erro na pesquisa.\n"
                + erro.getMessage()
        );
    }


    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNovoActionPerformed

    limparCampos();

    tabCliente.setSelectedIndex(0);

    }//GEN-LAST:event_btnNovoActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
         if (
            !SessaoUsuario.isMaster()
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Você não possui permissão para excluir clientes."
        );

        return;
    }

    if (
            idClienteSelecionado == 0
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Localize e carregue um cliente antes de excluir."
        );

        return;
    }

    int resposta =
            JOptionPane.showConfirmDialog(
                    this,
                    "Deseja realmente excluir este cliente?",
                    "Excluir Cliente",
                    JOptionPane.YES_NO_OPTION
            );

    if (
            resposta
            != JOptionPane.YES_OPTION
    ) {

        return;
    }

    try {

        boolean excluido =
                clienteDAO.excluir(
                        idClienteSelecionado
                );

        if (excluido) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cliente excluído com sucesso."
            );

            limparCampos();

            listarClientes();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Cliente não encontrado."
            );
        }

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Não foi possível excluir o cliente.\n"
                + "O cliente pode possuir registros vinculados.\n"
                + erro.getMessage()
        );
    }
    btnExcluir.setEnabled(
        SessaoUsuario.isMaster()
);
    if (
        !SessaoUsuario.isMaster()
);
        
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed

    if (
            idClienteSelecionado != 0
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Existe um cliente carregado para edição.\n"
                + "Utilize Alterar ou clique em Novo."
        );

        return;
    }

    if (!validarCampos()) {

        return;
    }

    try {

        Cliente cliente =
                criarClienteComCampos();

        long codigo =
                clienteDAO.cadastrar(
                        cliente
                );

        JOptionPane.showMessageDialog(
                this,
                "Cliente cadastrado com sucesso.\n"
                + "Código: "
                + codigo
        );

        limparCampos();

        listarClientes();

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Não foi possível cadastrar o cliente.\n"
                + erro.getMessage()
        );
    }

    }//GEN-LAST:event_btnSalvarActionPerformed

    private void txtEnderecoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEnderecoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEnderecoActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
  if (
            idClienteSelecionado == 0
    ) {

        JOptionPane.showMessageDialog(
                this,
                "Localize e carregue um cliente antes de alterar."
        );

        return;
    }

    if (!validarCampos()) {

        return;
    }

    int resposta =
            JOptionPane.showConfirmDialog(
                    this,
                    "Deseja salvar as alterações deste cliente?",
                    "Alterar Cliente",
                    JOptionPane.YES_NO_OPTION
            );

    if (
            resposta
            != JOptionPane.YES_OPTION
    ) {

        return;
    }

    try {

        Cliente cliente =
                criarClienteComCampos();

        boolean alterado =
                clienteDAO.alterar(
                        cliente
                );

        if (alterado) {

            JOptionPane.showMessageDialog(
                    this,
                    "Cliente alterado com sucesso."
            );

            limparCampos();

            listarClientes();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Nenhum registro foi alterado."
            );
        }

    } catch (Exception erro) {

        JOptionPane.showMessageDialog(
                this,
                "Não foi possível alterar o cliente.\n"
                + erro.getMessage()
        );
    }
    
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
    txtPesquisa.setText("");

    listarClientes();

    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnCarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarregarActionPerformed


    carregarClienteSelecionado();

    }//GEN-LAST:event_btnCarregarActionPerformed

    private void tblClientesComponentAdded(java.awt.event.ContainerEvent evt) {//GEN-FIRST:event_tblClientesComponentAdded
       
    }//GEN-LAST:event_tblClientesComponentAdded

    private void tblClientesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblClientesMouseClicked
          if (
            evt.getClickCount() == 2
    ) {

        carregarClienteSelecionado();
    }

    }//GEN-LAST:event_tblClientesMouseClicked

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
      limparCampos();

    }//GEN-LAST:event_btnCancelarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnCarregar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JButton btnNovo;
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox<String> cbmFiltro;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JComboBox<String> cmbUf;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane tabCliente;
    private javax.swing.JTable tblClientes;
    private javax.swing.JTextField txtBairro;
    private javax.swing.JTextField txtCep;
    private javax.swing.JTextField txtCidade;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtComplemento;
    private javax.swing.JTextField txtCpf;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtNumero;
    private javax.swing.JTextField txtPesquisa;
    private javax.swing.JTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
